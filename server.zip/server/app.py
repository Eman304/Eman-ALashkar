import streamlit as st
import numpy as np
import re
import pickle
from tensorflow.keras.preprocessing.sequence import pad_sequences
from tensorflow.keras.models import load_model
from nltk.tokenize import word_tokenize
from nltk.corpus import stopwords
from nltk.stem import WordNetLemmatizer
import nltk

# Download NLTK data
nltk.download('punkt')
nltk.download('stopwords')
nltk.download('wordnet')

# Constants
MAX_SEQUENCE_LENGTH = 20  # <-- تم التعديل هنا لتطابق الطول المستخدم في التدريب
LABEL_MAP = {0: "Negative", 1: "Neutral", 2: "Positive"}

# Load tokenizer
with open("tokenizer.pickle", "rb") as handle:
    tokenizer = pickle.load(handle)

# Load model
model = load_model("model1.keras")

# Text preprocessing function
def process_text(text):
    text = re.sub(r'\s+', ' ', text)
    text = re.sub(r'\W', ' ', text)
    text = re.sub(r'\s+[a-zA-Z]\s+', ' ', text)
    text = re.sub(r'[^a-zA-Z\s]', '', text)
    text = text.lower()

    tokens = word_tokenize(text)
    lemmatizer = WordNetLemmatizer()
    stop_words = set(stopwords.words("english"))

    cleaned = [lemmatizer.lemmatize(word) for word in tokens if word not in stop_words and len(word) >= 3]

    return " ".join(cleaned)

# Streamlit UI
st.set_page_config(page_title="Sentiment Analyzer", layout="centered")
st.title("Sentiment Analysis using LSTM")
st.write("This model classifies input text as:\n- Negative (0)\n- Neutral (1)\n- Positive (2)")

# User input
text_input = st.text_area("Enter your text here:")

if st.button("Predict Sentiment"):
    if not text_input.strip():
        st.warning("Please enter some text.")
    else:
        # Preprocess & tokenize
        processed = process_text(text_input)
        seq = tokenizer.texts_to_sequences([processed])
        padded = pad_sequences(seq, maxlen=MAX_SEQUENCE_LENGTH, padding='post', truncating='post')

        # Prediction
        pred = model.predict(padded)
        pred_class = int(np.argmax(pred))

        st.success(f"Predicted Sentiment: {LABEL_MAP[pred_class]} ({pred_class})")
